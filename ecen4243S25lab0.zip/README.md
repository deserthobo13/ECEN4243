# ECEN4243
Our FSM and Regfiles don't have anything essential to know; We attempted to test every single possible system of inputs for our two testbenches.

Use "vsim -do fsm.do" to run the fsm file.
Use "vsim -do regfile.do" to run the regfile file.
